var mixObject = {
	createPreview: function(containingDiv, labelText, callback) {
		debugger;
        this.context.coachViewData.previewDiv = containingDiv;
		callback();
	},
	propertyChanged: function(propertyName, propertyValue) {
		var previewDiv = this.context.coachViewData.previewDiv;
		if(propertyName === "@label"){
			previewDiv.getElementsByTagName("span")[0].textContent = propertyValue;
		} else if(propertyName === "image"){
			previewDiv.getElementsByTagName("img")[0].setAttribute("src", propertyValue);
		}
	},
};